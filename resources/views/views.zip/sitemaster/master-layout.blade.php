@include('layouts.header')
@yield('content')
@include('layouts.Footer')
@yield('script')
